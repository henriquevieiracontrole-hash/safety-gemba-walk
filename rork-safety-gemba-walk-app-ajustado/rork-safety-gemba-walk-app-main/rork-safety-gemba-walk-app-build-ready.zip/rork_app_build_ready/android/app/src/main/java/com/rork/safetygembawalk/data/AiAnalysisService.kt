package com.rork.safetygembawalk.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.rork.safetygembawalk.Config
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File

@Serializable
data class AiAnalysisResult(
    val riskDescription: String,
    val confidence: String,
    val recommendations: List<String>
)

class AiAnalysisService(private val context: Context) {
    private val client = HttpClient(Android) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }
    
    private val toolkitUrl = "https://toolkit.rork.app"
    private val secretKey = Config.EXPO_PUBLIC_RORK_TOOLKIT_SECRET_KEY
    
    suspend fun analyzeSafetyImage(imagePath: String): Result<AiAnalysisResult> {
        return try {
            // Resize and encode image to base64
            val base64Image = resizeAndEncodeImage(imagePath)
                ?: return Result.failure(Exception("Não foi possível processar a imagem"))
            
            val response = client.post("$toolkitUrl/v2/vercel/v1/chat/completions") {
                contentType(ContentType.Application.Json)
                header("Authorization", "Bearer $secretKey")
                setBody(buildAiRequest(base64Image))
            }
            
            if (response.status.value in 200..299) {
                val aiResponse: AiGatewayResponse = response.body()
                val content = aiResponse.choices.firstOrNull()?.message?.content
                    ?: return Result.failure(Exception("Resposta vazia da IA"))
                
                val result = parseAiResponse(content)
                Result.success(result)
            } else {
                Result.failure(Exception("Erro na análise: ${response.status}"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("Erro ao analisar imagem: ${e.message}"))
        }
    }
    
    private fun resizeAndEncodeImage(imagePath: String): String? {
        return try {
            val file = File(imagePath)
            if (!file.exists()) return null
            
            // Decode with sampling to reduce memory usage
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(imagePath, options)
            
            // Calculate sample size to get ~1024px max dimension
            val maxDimension = 1024
            var sampleSize = 1
            while (options.outWidth / sampleSize > maxDimension || 
                   options.outHeight / sampleSize > maxDimension) {
                sampleSize *= 2
            }
            
            options.apply {
                inJustDecodeBounds = false
                inSampleSize = sampleSize
            }
            
            val bitmap = BitmapFactory.decodeFile(imagePath, options) ?: return null
            
            // Compress to JPEG with quality 80
            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
            val bytes = outputStream.toByteArray()
            
            // Convert to base64
            "data:image/jpeg;base64,${Base64.encodeToString(bytes, Base64.NO_WRAP)}"
        } catch (e: Exception) {
            null
        }
    }
    
    private fun buildAiRequest(base64Image: String): AiRequest {
        return AiRequest(
            model = "google/gemini-3-flash",
            messages = listOf(
                Message(
                    role = "user",
                    content = listOf(
                        ContentItem(
                            type = "text",
                            text = PROMPT
                        ),
                        ContentItem(
                            type = "image_url",
                            imageUrl = ImageUrl(url = base64Image)
                        )
                    )
                )
            )
        )
    }
    
    private fun parseAiResponse(content: String): AiAnalysisResult {
        // Try to extract structured information from the AI response
        val lines = content.lines()
        
        // Extract risk description (usually the main paragraph)
        val riskDescription = lines
            .filter { it.isNotBlank() }
            .firstOrNull { !it.startsWith("-") && !it.startsWith("*") && !it.contains("confiança", ignoreCase = true) }
            ?: "Risco identificado na imagem"
        
        // Try to find confidence level
        val confidence = when {
            content.contains("alta confiança", ignoreCase = true) -> "Alta"
            content.contains("média confiança", ignoreCase = true) -> "Média"
            content.contains("baixa confiança", ignoreCase = true) -> "Baixa"
            else -> "Média"
        }
        
        // Extract recommendations (bullet points)
        val recommendations = lines
            .filter { it.trim().startsWith("-") || it.trim().startsWith("*") }
            .map { it.trim().removePrefix("-").removePrefix("*").trim() }
            .filter { it.isNotBlank() }
            .takeIf { it.isNotEmpty() } 
            ?: listOf("Verificar condição no local", "Tomar ação corretiva imediata se necessário")
        
        return AiAnalysisResult(
            riskDescription = riskDescription,
            confidence = confidence,
            recommendations = recommendations
        )
    }
    
    companion object {
        private const val PROMPT = """
            Você é um especialista em segurança do trabalho analisando imagens de inspeções Gemba Walk.
            Analise esta imagem e identifique:
            
            1. Condições ou atos inseguros visíveis
            2. Riscos potenciais à segurança
            3. Recomendações imediatas de correção
            
            Responda em português do Brasil de forma clara e objetiva, como um profissional de segurança.
            Seja específico sobre o que você identifica na imagem.
            
            Formato da resposta:
            - Descrição do risco identificado (1-2 frases)
            - Nível de confiança (alta/média/baixa)
            - 2-3 recomendações de ação corretiva em bullet points
        """
    }
}

// Data classes for AI Gateway API
@Serializable
data class AiRequest(
    val model: String,
    val messages: List<Message>
)

@Serializable
data class Message(
    val role: String,
    val content: List<ContentItem>
)

@Serializable
data class ContentItem(
    val type: String,
    val text: String? = null,
    val imageUrl: ImageUrl? = null
)

@Serializable
data class ImageUrl(
    val url: String
)

@Serializable
data class AiGatewayResponse(
    val choices: List<Choice>
)

@Serializable
data class Choice(
    val message: AssistantMessage
)

@Serializable
data class AssistantMessage(
    val content: String
)
