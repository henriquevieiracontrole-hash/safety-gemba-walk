package com.rork.safetygembawalk.viewmodels

import android.content.Context
import com.itextpdf.kernel.colors.DeviceRgb
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Image
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.properties.TextAlignment
import com.itextpdf.layout.properties.UnitValue
import com.itextpdf.io.image.ImageDataFactory
import com.rork.safetygembawalk.data.Inspection
import com.rork.safetygembawalk.data.formattedDate
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfReportGenerator(private val context: Context) {

    private val navyBlue = DeviceRgb(26, 54, 93)
    private val amber = DeviceRgb(214, 158, 46)
    private val white = DeviceRgb(255, 255, 255)
    private val lightGray = DeviceRgb(237, 242, 247)
    private val ahlstromPurple = DeviceRgb(107, 45, 120)  // Ahlstrom brand purple
    private val ahlstromOrange = DeviceRgb(255, 107, 53)  // Ahlstrom brand orange

    fun generateReport(inspections: List<Inspection>): String {
        val fileName = "Safety_Gemba_Walk_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.pdf"
        val file = File(context.getExternalFilesDir(null), fileName)

        PdfWriter(file.absolutePath).use { writer ->
            PdfDocument(writer).use { pdfDoc ->
                Document(pdfDoc, PageSize.A4).use { document ->
                    document.setMargins(40f, 40f, 40f, 40f)

                    addHeader(document)
                    addSummary(document, inspections)

                    inspections.forEachIndexed { index, inspection ->
                        if (index > 0) {
                            document.add(Paragraph("").setMarginTop(20f))
                        }
                        addInspectionDetail(document, inspection, index + 1)
                    }

                    addFooter(document)
                }
            }
        }

        return file.absolutePath
    }

    private fun addHeader(document: Document) {
        val headerTable = Table(floatArrayOf(1f, 3f)).useAllAvailableWidth()

        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")
        val helveticaFont = PdfFontFactory.createFont("Helvetica")

        // Logo cell (using Ahlstrom colors as placeholder)
        val logoCell = Cell()
            .setBackgroundColor(ahlstromPurple)
            .setPadding(15f)
            .setBorder(Border.NO_BORDER)
        logoCell.add(
            Paragraph("A")
                .setFont(boldFont)
                .setFontColor(ahlstromOrange)
                .setFontSize(36f)
                .setTextAlignment(TextAlignment.CENTER)
        )
        headerTable.addCell(logoCell)

        val titleCell = Cell()
            .setBackgroundColor(navyBlue)
            .setPadding(20f)
            .setBorder(Border.NO_BORDER)

        val titleText = Paragraph("SAFETY GEMBA WALK")
            .setFont(boldFont)
            .setFontColor(white)
            .setFontSize(28f)
            .setTextAlignment(TextAlignment.CENTER)
        titleCell.add(titleText)

        val subtitleText = Paragraph("Relatório de Inspeções de Segurança - Ahlstrom")
            .setFont(helveticaFont)
            .setFontColor(amber)
            .setFontSize(14f)
            .setTextAlignment(TextAlignment.CENTER)
            .setMarginTop(5f)
        titleCell.add(subtitleText)

        headerTable.addCell(titleCell)
        document.add(headerTable)

        document.add(
            Paragraph("Data: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}")
                .setFont(helveticaFont)
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.RIGHT)
                .setMarginTop(10f)
        )

        document.add(Paragraph("").setMarginTop(20f))
    }

    private fun addSummary(document: Document, inspections: List<Inspection>) {
        val summaryTable = Table(floatArrayOf(1f, 1f, 1f, 1f)).useAllAvailableWidth()
        summaryTable.setMarginBottom(20f)

        val total = inspections.size
        val immediate = inspections.count { it.isImmediateAction }
        val withWorkOrder = inspections.count { it.hasWorkOrder }
        val completed = inspections.count { it.status.name == "COMPLETED" }

        addSummaryCard(summaryTable, "Total Inspeções", total.toString(), navyBlue)
        addSummaryCard(summaryTable, "Ações Imediatas", immediate.toString(), amber)
        addSummaryCard(summaryTable, "Com O.S.", withWorkOrder.toString(), DeviceRgb(56, 161, 105))
        addSummaryCard(summaryTable, "Concluídas", completed.toString(), DeviceRgb(49, 130, 206))

        document.add(summaryTable)
        document.add(Paragraph("").setMarginTop(10f))
    }

    private fun addSummaryCard(table: Table, label: String, value: String, color: DeviceRgb) {
        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")
        val helveticaFont = PdfFontFactory.createFont("Helvetica")

        val cell = Cell()
            .setBackgroundColor(color)
            .setPadding(15f)
            .setBorder(Border.NO_BORDER)

        val valueParagraph = Paragraph(value)
            .setFont(boldFont)
            .setFontColor(white)
            .setFontSize(24f)
            .setTextAlignment(TextAlignment.CENTER)
        cell.add(valueParagraph)

        val labelParagraph = Paragraph(label)
            .setFont(helveticaFont)
            .setFontColor(white)
            .setFontSize(10f)
            .setTextAlignment(TextAlignment.CENTER)
            .setMarginTop(5f)
        cell.add(labelParagraph)

        table.addCell(cell)
    }

    private fun addInspectionDetail(document: Document, inspection: Inspection, number: Int) {
        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")
        val helveticaFont = PdfFontFactory.createFont("Helvetica")

        val containerTable = Table(floatArrayOf(1f)).useAllAvailableWidth()
        containerTable.setBorder(Border.NO_BORDER)

        val headerCell = Cell()
            .setBackgroundColor(navyBlue)
            .setPadding(12f)
            .setBorder(Border.NO_BORDER)

        val headerParagraph = Paragraph("Inspeção #$number - ${inspection.formattedDate()}")
            .setFont(boldFont)
            .setFontColor(white)
            .setFontSize(14f)
        headerCell.add(headerParagraph)

        containerTable.addCell(headerCell)

        val contentCell = Cell()
            .setBackgroundColor(lightGray)
            .setPadding(15f)
            .setBorder(Border.NO_BORDER)

        addDetailRow(contentCell, "Condição Insegura:", inspection.unsafeCondition)
        addDetailRow(contentCell, "Descrição:", inspection.description)
        addDetailRow(contentCell, "Ação Imediata:", inspection.immediateAction)
        addDetailRow(contentCell, "Local:", inspection.location)
        addDetailRow(contentCell, "Inspetor:", inspection.inspectorName)

        if (inspection.hasWorkOrder) {
            addDetailRow(contentCell, "Ordem de Serviço:", inspection.workOrderNumber ?: "N/A")
        }

        if (inspection.isImmediateAction) {
            val actionParagraph = Paragraph("Ação Imediata Realizada")
                .setFont(boldFont)
                .setFontColor(DeviceRgb(56, 161, 105))
                .setMarginTop(10f)
            contentCell.add(actionParagraph)
        }

        addPhotosToCell(contentCell, inspection)

        containerTable.addCell(contentCell)
        document.add(containerTable)
    }

    private fun addDetailRow(cell: Cell, label: String, value: String) {
        if (value.isBlank()) return

        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")
        val helveticaFont = PdfFontFactory.createFont("Helvetica")

        val labelParagraph = Paragraph(label)
            .setFont(boldFont)
            .setFontSize(10f)
        
        val paragraph = Paragraph()
        paragraph.add(labelParagraph)
        paragraph.add(Paragraph(" $value").setFont(helveticaFont).setFontSize(10f))
        paragraph.setMarginBottom(5f)
        cell.add(paragraph)
    }

    private fun addPhotosToCell(cell: Cell, inspection: Inspection) {
        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")

        val photoTable = Table(floatArrayOf(1f, 1f)).useAllAvailableWidth()
        photoTable.setMarginTop(15f)

        inspection.beforePhotoPath?.let { path ->
            val photoCell = Cell().setBorder(Border.NO_BORDER)
            val titleParagraph = Paragraph("Foto - Antes")
                .setFont(boldFont)
                .setFontSize(9f)
                .setMarginBottom(5f)
            photoCell.add(titleParagraph)
            addImageToCell(photoCell, path)
            photoTable.addCell(photoCell)
        }

        inspection.afterPhotoPath?.let { path ->
            val photoCell = Cell().setBorder(Border.NO_BORDER)
            val titleParagraph = Paragraph("Foto - Depois")
                .setFont(boldFont)
                .setFontSize(9f)
                .setMarginBottom(5f)
            photoCell.add(titleParagraph)
            addImageToCell(photoCell, path)
            photoTable.addCell(photoCell)
        }

        if (photoTable.numberOfRows > 0) {
            cell.add(photoTable)
        }
    }

    private fun addImageToCell(cell: Cell, imagePath: String) {
        val italicFont = PdfFontFactory.createFont("Helvetica-Oblique")

        try {
            val file = File(imagePath)
            if (file.exists()) {
                val imageData = ImageDataFactory.create(imagePath)
                val image = Image(imageData)
                image.setWidth(UnitValue.createPercentValue(100f))
                cell.add(image)
            }
        } catch (e: Exception) {
            val errorParagraph = Paragraph("[Imagem não disponível]")
                .setFont(italicFont)
                .setFontSize(8f)
            cell.add(errorParagraph)
        }
    }

    private fun addFooter(document: Document) {
        val boldFont = PdfFontFactory.createFont("Helvetica-Bold")
        val helveticaFont = PdfFontFactory.createFont("Helvetica")

        document.add(Paragraph("").setMarginTop(30f))

        val footerTable = Table(floatArrayOf(1f, 1f)).useAllAvailableWidth()

        val footerCellLeft = Cell()
            .setBackgroundColor(ahlstromPurple)
            .setPadding(15f)
            .setBorder(Border.NO_BORDER)

        footerCellLeft.add(
            Paragraph("AHLSTROM")
                .setFont(boldFont)
                .setFontColor(ahlstromOrange)
                .setFontSize(14f)
                .setTextAlignment(TextAlignment.LEFT)
        )

        footerCellLeft.add(
            Paragraph("Safety Gemba Walk")
                .setFont(helveticaFont)
                .setFontColor(white)
                .setFontSize(10f)
                .setTextAlignment(TextAlignment.LEFT)
                .setMarginTop(3f)
        )

        val footerCellRight = Cell()
            .setBackgroundColor(ahlstromPurple)
            .setPadding(15f)
            .setBorder(Border.NO_BORDER)

        footerCellRight.add(
            Paragraph("Relatório gerado automaticamente")
                .setFont(helveticaFont)
                .setFontColor(white)
                .setFontSize(8f)
                .setTextAlignment(TextAlignment.RIGHT)
        )

        footerCellRight.add(
            Paragraph(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()))
                .setFont(helveticaFont)
                .setFontColor(ahlstromOrange)
                .setFontSize(8f)
                .setTextAlignment(TextAlignment.RIGHT)
                .setMarginTop(5f)
        )

        footerTable.addCell(footerCellLeft)
        footerTable.addCell(footerCellRight)
        document.add(footerTable)
    }
}
